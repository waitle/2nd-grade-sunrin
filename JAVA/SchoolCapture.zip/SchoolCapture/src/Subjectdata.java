public class Subjectdata {
	String name = new String();
	String teacher = new String();
	String Email = new String();
	String phone = new String();
}
