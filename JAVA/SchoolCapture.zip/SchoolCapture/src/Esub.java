import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

@SuppressWarnings("serial")
public class Esub extends JPanel {
	private JTextField name;
	private JTextField teacher;
	private JTextField email;
	private JTextField phone;
	private JTable table;
	static String[][] subjects = new String[15][4];// ǥ ������ �����ֱ� ���� ������ �迭
	Vector<String> date = new Vector<String>(4);
	String[]raw = new String[4];
	Vector<String []> data = new Vector<String []>(15);
	final static String[] cal = { "����", "������", "�̸���", "����ó" };

	/**
	 * Create the this.
	 */
	public Esub() {
		setBackground(Color.DARK_GRAY);
		this.setSize(800, 550);
		this.setVisible(true);
		setLayout(null);

		name = new JTextField();
		name.setColumns(10);
		name.setBounds(332, 352, 116, 21);
		this.add(name);

		teacher = new JTextField();
		teacher.setColumns(10);
		teacher.setBounds(332, 383, 116, 21);
		this.add(teacher);

		email = new JTextField();
		email.setColumns(10);
		email.setBounds(332, 414, 116, 21);
		this.add(email);

		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(332, 445, 116, 21);
		this.add(phone);

		JLabel Lname = new JLabel("\uACFC\uBAA9\uBA85");
		Lname.setForeground(Color.WHITE);
		Lname.setBounds(243, 355, 57, 15);
		this.add(Lname);

		JLabel Lteacher = new JLabel("\uC120\uC0DD\uB2D8 \uC131\uD568");
		Lteacher.setForeground(Color.WHITE);
		Lteacher.setBounds(243, 386, 69, 15);
		this.add(Lteacher);

		JLabel Lemail = new JLabel("\uC774\uBA54\uC77C");
		Lemail.setForeground(Color.WHITE);
		Lemail.setBounds(243, 417, 57, 15);
		this.add(Lemail);

		JLabel Lphone = new JLabel("\uC5F0\uB77D\uCC98");
		Lphone.setForeground(Color.WHITE);
		Lphone.setBounds(243, 448, 57, 15);
		this.add(Lphone);

		// ������ư
		JButton delete = new JButton("\uC0AD\uC81C");
		delete.setForeground(Color.DARK_GRAY);
		delete.setBackground(Color.LIGHT_GRAY);
		delete.setBounds(505, 505, 97, 23);
		this.add(delete);

		// Ȯ�ι�ư
		JButton confirm = new JButton("\uD655\uC778");
		confirm.setForeground(Color.DARK_GRAY);
		confirm.setBackground(Color.LIGHT_GRAY);
		confirm.setBounds(614, 505, 97, 23);
		this.add(confirm);

		
		
		DefaultTableModel mod = new DefaultTableModel(data, date) { // �� ����
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		date.add("�����");
		date.add("������");
		date.add("�̸���");
		date.add("����ó");
		// �ð�ǥ
		table = new JTable(mod);
		table.setModel(mod);
		table.setBounds(1, 201, 669, 36);
		table.getTableHeader().setReorderingAllowed(false); // �̵� �Ұ�
		table.getTableHeader().setResizingAllowed(true); // ũ�� ���� �Ұ�
		table.setRowHeight(55); // ĭ�� ���� ũ��

		JScrollPane scrollPaneR = new JScrollPane(table);
		scrollPaneR.setBounds(59, 35, 671, 273);
		add(scrollPaneR);

		Loadfile lf = new Loadfile();
		add(lf);

		// Ȯ�ι�ư�� ��������
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				raw[0]=name.getText();// �ʵ��� ������� ��ҿ� �߰�
				raw[1]=teacher.getText();
				raw[2]=email.getText();
				raw[3]=phone.getText();
				data.add(raw);
				
				name.setText("");
				teacher.setText("");
				email.setText("");
				phone.setText("");
				
				mod.fireTableDataChanged();
			}
			
		});

		// ��ҹ�ư�� ��������
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				name.setText("");
				teacher.setText("");
				email.setText("");
				phone.setText("");

				mod.fireTableDataChanged();
			}
		});
		// �ð�ǥ ���� Ŭ��������
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.rowAtPoint(e.getPoint());
				int col = table.columnAtPoint(e.getPoint());
				if (row >= 0 && col >= 0) {
					name.setText(table.getValueAt(row, 0).toString());
					teacher.setText(table.getValueAt(row, 1).toString());
					email.setText(table.getValueAt(row, 2).toString());
					phone.setText(table.getValueAt(row, 3).toString());

				}
			}
		});

	}
}
